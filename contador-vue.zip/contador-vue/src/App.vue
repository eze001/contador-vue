<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <button v-on:click="funcion()">Clickea aqui</button>
    {{contador}}
  </div>
</template>

<script>

export default {
  name: 'App',
  data:function(){
    return{
      contador:0
    };
  },
  methods:{
    funcion:function(){
      this.contador++;
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
